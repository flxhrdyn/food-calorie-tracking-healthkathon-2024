# food-detection-v2 > 2024-06-17 5:34am
https://universe.roboflow.com/c241ps253/food-detection-v2

Provided by a Roboflow user
License: undefined

